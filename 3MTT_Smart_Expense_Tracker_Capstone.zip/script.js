const form = document.getElementById("expenseForm");
const list = document.getElementById("expenseList");
const totalEl = document.getElementById("total");
const countEl = document.getElementById("count");
const empty = document.getElementById("empty");
const clearBtn = document.getElementById("clearBtn");

let expenses = JSON.parse(localStorage.getItem("expenses") || "[]");

function render() {
  list.innerHTML = "";
  let total = expenses.reduce((sum, item) => sum + item.amount, 0);
  totalEl.textContent = `₦${total.toFixed(2)}`;
  countEl.textContent = expenses.length;
  empty.style.display = expenses.length ? "none" : "block";

  expenses.forEach((item, index) => {
    const li = document.createElement("li");
    li.innerHTML = `<span><strong>${item.description}</strong><br>${item.category}</span>
                    <span>₦${item.amount.toFixed(2)}
                    <button onclick="removeExpense(${index})">Delete</button></span>`;
    list.appendChild(li);
  });
}

function save() {
  localStorage.setItem("expenses", JSON.stringify(expenses));
  render();
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const description = document.getElementById("description").value.trim();
  const amount = Number(document.getElementById("amount").value);
  const category = document.getElementById("category").value;
  if (!description || amount <= 0 || !category) return;

  expenses.push({ description, amount, category });
  form.reset();
  save();
});

function removeExpense(index) {
  expenses.splice(index, 1);
  save();
}

clearBtn.addEventListener("click", () => {
  expenses = [];
  save();
});

render();
