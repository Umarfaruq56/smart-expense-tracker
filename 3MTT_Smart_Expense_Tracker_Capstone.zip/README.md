# Smart Expense Tracker — 3MTT Capstone Project

## Project title
Smart Expense Tracker

## Description
A simple responsive web application that helps users record, categorize and monitor daily expenses.

## Technologies
- HTML5
- CSS3
- JavaScript
- Browser Local Storage

## Main features
- Add an expense and category
- Calculate total expenses automatically
- Count recorded expenses
- Delete individual expenses
- Clear all expenses
- Save data in the browser using Local Storage
- Responsive design for mobile and desktop

## How to run
Open `index.html` in a web browser.

## Demo
Record a short screen video showing:
1. Opening the application
2. Adding two or three expenses
3. Showing the total update
4. Deleting an expense
5. Refreshing the page to show that the data remains saved
